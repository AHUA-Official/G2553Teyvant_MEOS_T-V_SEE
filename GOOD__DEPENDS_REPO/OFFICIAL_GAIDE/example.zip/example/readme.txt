Please beware that different variants of the G2xx3 devices have different analog 
peripheral sets. Therefore certain peripheral examples are only applicable to 
certain devices, as follows.


??????????
ADC10 code examples applicable for G2x33 & G2x53 devices
COMP_A+ code examples applicable for G2x13 & G2x53 devices

        CompA     ADC10     
2x03      
2x33                x  
2x13      x           
2x53      x         x

