/*
 *  --> ���ļ�����ѧϰʹ�ã��Ͻ����á�
 */
#include <OELD_Display/oled.h>
#include <OELD_Display/oledfont.h>

#ifdef oled_iic_04
/**********************************************
//IIC Start
**********************************************/
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void IIC_Start()
{
   SCL_H;
   SDA_H;
   SDA_L;
   SCL_L;
}

/**********************************************
//IIC Stop
**********************************************/
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void IIC_Stop()
{
   SCL_L;
   SDA_L;
   SCL_H;
   SDA_H;
}

/**********************************************
// ͨ��I2C����дһ���ֽ�
**********************************************/
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void Write_IIC_Byte(uint8_t IIC_Byte)
{
    uint8_t i;
    for(i=0;i<8;i++)
    {
        if(IIC_Byte & 0x80)
            SDA_H;
        else
            SDA_L;
        SCL_H;
        SCL_L;
        IIC_Byte<<=1;
    }
    SDA_H;
    SCL_H;
    SCL_L;
}



#else

/**********************************************
// ͨ��SPI����дһ���ֽ�
**********************************************/
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void SW_Write_SPI_Byte(uint8_t SPI_Byte)
{
    char bit_mask, k;
    bit_mask = 0x80;                                    // MSB order first
    for (k = 0;  k < 8;  k++)
    {
        if(SPI_Byte & bit_mask)                             // load bit value
        {
            SW_SPI_MOSI(1);
        }else{
            SW_SPI_MOSI(0);
        }
        SW_SPI_CLK(1);                                // clock it out
        bit_mask /= 2;                                  // next bit (the "/= 2" provides necessary delay over ">> 1")
        SW_SPI_CLK(0);                               // clock reset
    }
}


//**********************************************
// ͨ��SPI���߶�һ���ֽ�
//**********************************************
uint8_t SW_Read_SPI_Byte(void)
{
    uint8_t i;
    uint8_t SPI_Byte = 0;

    for (i = 0x01; i != 0; i <<= 1) //��λ��ǰ����λ��ȡ
    {
        if (SW_SPI_MISO != 0)  //���ȶ�ȡ��ʱ��IO���ţ�������dat�еĶ�Ӧλ
        {
            SPI_Byte |= i;
        }
        SW_SPI_CLK(1);                //Ȼ������ʱ��
        SW_SPI_CLK(0);                //������ʱ�ӣ����һ��λ�Ĳ���
    }
  return SPI_Byte;              //��󷵻ض������ֽ�����
}

#endif
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void OLED_Write_Data(uint8_t DATA)
{
    #ifdef oled_iic_04
        IIC_Start();
        Write_IIC_Byte(0x78);
        Write_IIC_Byte(0x40);           //write data
        Write_IIC_Byte(DATA);
        IIC_Stop();
    #else
        SW_SPI_DC(1);
        SW_SPI_CS(0);
        SW_Write_SPI_Byte(DATA);
        SW_SPI_CS(1);
        SW_SPI_DC(1);
    #endif
}

/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void OLED_Write_Cmd(uint8_t CMD)
{
    #ifdef oled_iic_04
        IIC_Start();
        Write_IIC_Byte(0x78);            //Slave address,SA0=0
        Write_IIC_Byte(0x00);            //write command
        Write_IIC_Byte(CMD);
        IIC_Stop();
    #else
        SW_SPI_DC(0);
        SW_SPI_CS(0);
        SW_Write_SPI_Byte(CMD);
        SW_SPI_CS(1);
        SW_SPI_DC(1);
    #endif
}



/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void OLED_Set_Pos(uint8_t x, uint8_t y)
{
    OLED_Write_Cmd(0xb0+y);
    OLED_Write_Cmd(((x&0xf0)>>4)|0x10);
    OLED_Write_Cmd((x&0x0f)|0x01);
} 
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void OLED_Fill(uint8_t bmp_dat)
{
    uint8_t y,x;
    for(y=0;y<8;y++)
    {
        OLED_Write_Cmd(0xb0+y);
        OLED_Write_Cmd(0x01);
        OLED_Write_Cmd(0x10);
        for(x=0;x<X_WIDTH;x++)
        OLED_Write_Data(bmp_dat);
    }
}
/*********************OLED��λ************************************/
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void OLED_CLS(void)
{
    uint8_t y,x;
    for(y=0;y<8;y++)
    {
        OLED_Write_Cmd(0xb0+y);
        OLED_Write_Cmd(0x00);
        OLED_Write_Cmd(0x10);
        for(x=0;x<X_WIDTH;x++)
        OLED_Write_Data(0);
    }
}
/*********************OLED��ʼ��************************************/
/********************************************************
 *
 *
 *
 *
 *
********************************************************/
void OLED_Init(void)
{

#ifdef  oled_iic_04
    P4DIR |= BIT1 + BIT2;
#else
    P2DIR |=  BIT3 + BIT4 + BIT5;
    P1DIR |=  BIT6 + BIT7;

    SW_SPI_REST(1);
    delay_ms(100);
    SW_SPI_REST(0);
    delay_ms(100);
    SW_SPI_REST(1);
#endif
    __delay_cycles(5000);//��ʼ��֮ǰ����ʱ����Ҫ��
    OLED_Write_Cmd(0xae);//--turn off oled panel
    OLED_Write_Cmd(0x00);//---set low column address
    OLED_Write_Cmd(0x10);//---set high column address
    OLED_Write_Cmd(0x40);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
    OLED_Write_Cmd(0x81);//--set contrast control register
    OLED_Write_Cmd(Brightness); // Set SEG Output Current Brightness
    OLED_Write_Cmd(0xa1);//--Set SEG/Column Mapping     0xa0���ҷ��� 0xa1����
    OLED_Write_Cmd(0xc8);//Set COM/Row Scan Direction   0xc0���·��� 0xc8����
    OLED_Write_Cmd(0xa6);//--set normal display
    OLED_Write_Cmd(0xa8);//--set multiplex ratio(1 to 64)
    OLED_Write_Cmd(0x3f);//--1/64 duty
    OLED_Write_Cmd(0xd3);//-set display offset  Shift Mapping RAM Counter (0x00~0x3F)
    OLED_Write_Cmd(0x00);//-not offset
    OLED_Write_Cmd(0xd5);//--set display clock divide ratio/oscillator frequency
    OLED_Write_Cmd(0x80);//--set divide ratio, Set Clock as 100 Frames/Sec
    OLED_Write_Cmd(0xd9);//--set pre-charge period
    OLED_Write_Cmd(0xf1);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
    OLED_Write_Cmd(0xda);//--set com pins hardware configuration
    OLED_Write_Cmd(0x12);
    OLED_Write_Cmd(0xdb);//--set vcomh
    OLED_Write_Cmd(0x40);//Set VCOM Deselect Level
    OLED_Write_Cmd(0x20);//-Set Page Addressing Mode (0x00/0x01/0x02)
    OLED_Write_Cmd(0x02);//
    OLED_Write_Cmd(0x8d);//--set Charge Pump enable/disable
    OLED_Write_Cmd(0x14);//--set(0x10) disable
    OLED_Write_Cmd(0xa4);// Disable Entire Display On (0xa4/0xa5)
    OLED_Write_Cmd(0xa6);// Disable Inverse Display On (0xa6/a7)
    OLED_Write_Cmd(0xaf);//--turn on oled panel
    OLED_Fill(0x00); //��ʼ����
    OLED_Set_Pos(0,0);
} 

void OLED_WR_Byte(unsigned dat,unsigned cmd)
{
    if(cmd) OLED_Write_Data(dat);
    else OLED_Write_Cmd(dat);
}
void fill_picture(unsigned char fill_Data)
{
    unsigned char m,n;
    for(m=0;m<8;m++)
    {
        OLED_WR_Byte(0xb0+m,0);     //page0-page1
        OLED_WR_Byte(0x00,0);       //low column start address
        OLED_WR_Byte(0x10,0);       //high column start address
        for(n=0;n<128;n++)
            {
                OLED_WR_Byte(fill_Data,1);
            }
    }
}
void OLED_ShowCHinese(unsigned char x,unsigned char y,unsigned char no)
{
    unsigned char t,adder=0;
    OLED_Set_Pos(x,y);
    for(t=0;t<16;t++)
        {
                OLED_WR_Byte(Hzk[2*no][t],OLED_DATA);
                adder+=1;
     }
        OLED_Set_Pos(x,y+1);
    for(t=0;t<16;t++)
            {
                OLED_WR_Byte(Hzk[2*no+1][t],OLED_DATA);
                adder+=1;
      }
}

//��ָ��λ����ʾһ���ַ�,���������ַ�
//x:0~127
//y:0~63
//mode:0,������ʾ;1,������ʾ
//size:ѡ������ 16/12
void OLED_ShowChar(unsigned char x,unsigned char y,unsigned char chr,unsigned char Char_Size)
{
    unsigned char c=0,i=0;
        c=chr-' ';//�õ�ƫ�ƺ��ֵ
        if(x>128-1){x=0;y=y+2;}
        if(Char_Size ==16)
            {
            OLED_Set_Pos(x,y);
            for(i=0;i<8;i++)
            OLED_WR_Byte(F8X16[c*16+i],OLED_DATA);
            OLED_Set_Pos(x,y+1);
            for(i=0;i<8;i++)
            OLED_WR_Byte(F8X16[c*16+i+8],OLED_DATA);
            }
            else {
                OLED_Set_Pos(x,y);
                for(i=0;i<6;i++)
                OLED_WR_Byte(F6x8[c][i],OLED_DATA);

            }
}

//��ʾһ���ַ��Ŵ�
void OLED_ShowString(unsigned char x,unsigned char y,unsigned char *chr,unsigned char Char_Size)
{
   unsigned char j=0;
   while (chr[j]!='\0')
   {
       OLED_ShowChar(x,y,chr[j],Char_Size);
     x+=8;
     if(x>128)
     {
       x=0;
       y+=2;
     }
     j++;
   }
}

//m^n����
unsigned long oled_pow(unsigned char m,unsigned char n)
{
    unsigned long result=1;
    while(n--)result*=m;
    return result;
}


//��ʾһ������
void OLED_ShowNum(unsigned char x,unsigned char y,unsigned long num,unsigned char len,unsigned char size2)
{
    unsigned char t,temp;
    unsigned char enshow=0;
    for(t=0;t<len;t++)
    {
        temp=(num/oled_pow(10,len-t-1))%10;
        if(enshow==0&&t<(len-1))
        {
            if(temp==0)
            {
                OLED_ShowChar(x+(size2/2)*t,y,' ',size2);
                continue;
            }else enshow=1;
        }
        OLED_ShowChar(x+(size2/2)*t,y,temp+'0',size2);
    }
}



