/*
 *  --> ���ļ�����ѧϰʹ�ã��Ͻ����á�
 */

#include <User_config.h>

#ifndef __OLED_H
#define __OLED_H

//#define oled_iic_04    //ȡ��ע����ʹ������iic oled
#ifdef  oled_iic_04

#define high 1
#define low 0

// ------------------------------------------------------------
// IO��ģ��I2Cͨ��
// SCL��P4.2
// SDA��P4.1
// ------------------------------------------------------------
#define SCL_H P4OUT |=  BIT2  //����ʱ��
#define SCL_L P4OUT &= ~BIT2  //����ʱ��
#define SDA_H P4OUT |=  BIT1  //��������
#define SDA_L P4OUT &= ~BIT1  //��������

#else

// ------------------------------------------------------------
// IO��ģ��SPIͨ��
//   CLK  --> P4.3
//   MOSI --> P4.0
//   SIMO <-- P2.3
//   REST --> P2.6
//   DC   --> P8.2
//   CS   --> P8.1
// ------------------------------------------------------------

// �궨�壺SPI_CLK����
#define SW_SPI_CLK(a)   if(a == 1) P2OUT |= BIT3; else P2OUT &= ~BIT3
// �궨�壺SPI_MOSI����
#define SW_SPI_MOSI(a)  if(a == 1) P2OUT |= BIT4; else P2OUT &= ~BIT4
// �궨�壺SPI_RES����

#define SW_SPI_MISO (P2IN & BIT0)

#define SW_SPI_REST(a)  if(a == 1) P2OUT |= BIT5; else P2OUT &= ~BIT5
// �궨�壺SPI_DC����
#define SW_SPI_DC(a)    if(a == 1) P1OUT |= BIT6; else P1OUT &= ~BIT6
// �궨�壺SPI_CS����
#define SW_SPI_CS(a)    if(a == 1) P1OUT |= BIT7; else P1OUT &= ~BIT7

#endif

#define Brightness  0xCF
#define X_WIDTH     128
#define Y_WIDTH     64
#define OLED_CMD  0 //д����
#define OLED_DATA 1 //д����

#ifdef  oled_iic_04
    extern void IIC_Start();
    extern void IIC_Stop();
    extern void Write_IIC_Byte(uint8_t IIC_Byte);
#else
    extern void SW_Write_SPI_Byte(uint8_t SPI_Byte);
    extern uint8_t SW_Read_SPI_Byte(void);
#endif

extern void OLED_Write_Data(uint8_t DATA);
extern void OLED_Write_Cmd(uint8_t CMD);
extern void OLED_Set_Pos(uint8_t x, uint8_t y);
extern void OLED_Fill(uint8_t bmp_dat);
extern void OLED_CLS(void);
extern void OLED_Init(void);
extern void OLED_ShowCHinese(unsigned char x,unsigned char y,unsigned char no);
extern void OLED_ShowChar(unsigned char x,unsigned char y,unsigned char chr,unsigned char Char_Size);
extern void OLED_ShowString(unsigned char x,unsigned char y,unsigned char *chr,unsigned char Char_Size);
extern void OLED_ShowNum(unsigned char x,unsigned char y,unsigned long num,unsigned char len,unsigned char size2);

#endif  
	 



